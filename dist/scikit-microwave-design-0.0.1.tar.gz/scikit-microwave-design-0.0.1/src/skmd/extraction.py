"""Module on extraction of network parameters"""
