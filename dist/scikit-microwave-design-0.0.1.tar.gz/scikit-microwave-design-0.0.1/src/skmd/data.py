"""Module on data handling"""
