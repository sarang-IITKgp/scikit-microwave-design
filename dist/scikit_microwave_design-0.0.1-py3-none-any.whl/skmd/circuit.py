"""Module for class circuit"""
