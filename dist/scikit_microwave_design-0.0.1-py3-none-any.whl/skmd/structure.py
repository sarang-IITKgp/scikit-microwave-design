"""Module containing physical structures"""

import numpy as np
