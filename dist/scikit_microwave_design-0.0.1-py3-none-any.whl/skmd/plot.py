"""Module containg functions on visualization"""
